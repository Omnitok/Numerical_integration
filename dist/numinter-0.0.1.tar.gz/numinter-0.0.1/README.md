We each create a branch to work on, than merge that together in the end.

Tasks:

  Leo - 
  
  Nikhil - 
  
  Richard - 
  
  János - github, plot
