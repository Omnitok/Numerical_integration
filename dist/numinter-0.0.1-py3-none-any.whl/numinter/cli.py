import argparse

print("Hello")
print(__name__)

def main():
    pass


